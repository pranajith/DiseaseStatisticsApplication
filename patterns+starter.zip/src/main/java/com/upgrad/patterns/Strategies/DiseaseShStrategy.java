package com.upgrad.patterns.Strategies;

import org.springframework.stereotype.Component;
import com.upgrad.patterns.Entity.DiseaseShResponse;
import com.upgrad.patterns.Interfaces.IndianDiseaseStat;
import com.upgrad.patterns.config.RestServiceGenerator;

import org.springframework.web.client.RestTemplate;

@Component
public class DiseaseShStrategy implements IndianDiseaseStat {

    private static final String DISEASE_SH_URL = "https://corona.lmao.ninja/v2/countries/India";

    @Override
    public int getActiveCount() {
        RestTemplate restTemplate = RestServiceGenerator.getClient();
        DiseaseShResponse response = restTemplate.getForObject(DISEASE_SH_URL, DiseaseShResponse.class);

        if (response != null) {
            return response.getActive();  // Get active cases from response
        }
        return 0; // fallback if response null
    }
}
