package com.upgrad.patterns.Strategies;

import org.springframework.stereotype.Component;
import com.upgrad.patterns.Entity.JohnHopkinResponse;
import com.upgrad.patterns.Interfaces.IndianDiseaseStat;
import com.upgrad.patterns.config.RestServiceGenerator;

import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Component
public class JohnHopkinsStrategy implements IndianDiseaseStat {

    private static final String JOHN_HOPKINS_URL = "https://corona.lmao.ninja/v2/jhucsse";

    @Override
    public int getActiveCount() {
        RestTemplate restTemplate = RestServiceGenerator.getClient();

        JohnHopkinResponse[] responses = restTemplate.getForObject(JOHN_HOPKINS_URL, JohnHopkinResponse[].class);

        if (responses != null) {
            return Arrays.stream(responses)
                    .filter(data -> "India".equalsIgnoreCase(data.getCountry())) // Filter for India
                    .mapToInt(data -> data.getStats().getConfirmed())            // Sum confirmed cases
                    .sum();
        }

        return 0; // fallback if response null
    }
}