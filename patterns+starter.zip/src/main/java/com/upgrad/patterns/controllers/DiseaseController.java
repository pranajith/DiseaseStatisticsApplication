package com.upgrad.patterns.controllers;

import com.upgrad.patterns.service.DiseaseCountFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/disease")
public class DiseaseController {

    @Autowired
    private DiseaseCountFacade diseaseCountFacade;

    @GetMapping("/india")
    public String getIndiaDiseaseCount() {
        return "India Disease Count: " + diseaseCountFacade.getIndiaDiseaseStat();
    }

    @GetMapping("/count")
    public String getDiseaseCount() {
        return "Disease Sh Count: " + diseaseCountFacade.getDiseaseShCount();
    }

    @GetMapping("/johnhopkin")
    public String getJohnHopkinCount() {
        return "Johns Hopkins Disease Count: " + diseaseCountFacade.getJohnHopkinCount();
    }

    @GetMapping("/infectedRatio")
    public String getInfectedRatio() {
        return "Infected Ratio: " + diseaseCountFacade.getInfectedRatio();
    }
}
