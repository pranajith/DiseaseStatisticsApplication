package com.upgrad.patterns.Interfaces;

public interface DiseaseDataStrategy {
    float getData();
}
