package com.upgrad.patterns.Middleware;

import com.upgrad.patterns.authentication.Authenticator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AuthFilter {

    @Autowired
    private Authenticator authenticator;

    public void filter() {
        // Using the authenticator method correctly
        String response = authenticator.getAuthProcessor();
        System.out.println(response);
    }
}
