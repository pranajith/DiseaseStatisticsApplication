package com.upgrad.patterns.authentication;

import org.springframework.stereotype.Component;

@Component
public class Authenticator {

    public String getAuthProcessor() {
        // Dummy implementation
        return "Auth Processor Called";
    }
}


