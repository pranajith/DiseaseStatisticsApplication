package com.upgrad.patterns.Authentication;

public class BasicAuthProvider extends AuthenticationProvider {

    private String username;
    private String password;

    // Constructor to initialize username and password
    public BasicAuthProvider(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Implement the abstract method Authenticate
    @Override
    public boolean Authenticate() {
        // Sample basic auth logic, replace with your real validation
        return "admin".equals(username) && "password".equals(password);
    }

    // Getters (optional, if needed)
    public String getUsername() { return username; }
    public String getPassword() { return password; }
}
