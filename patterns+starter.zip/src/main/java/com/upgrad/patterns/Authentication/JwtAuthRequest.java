package com.upgrad.patterns.Authentication;

public class JwtAuthRequest {
    private String token;

    public JwtAuthRequest(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}

