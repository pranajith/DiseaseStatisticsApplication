package com.upgrad.patterns.Authentication;

public abstract class AuthenticationProvider {
    // Abstract method to be implemented by subclasses
    public abstract boolean Authenticate();
}
