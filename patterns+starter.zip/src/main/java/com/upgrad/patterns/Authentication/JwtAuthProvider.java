package com.upgrad.patterns.Authentication;

public class JwtAuthProvider extends AuthenticationProvider {

    private String token;

    // Constructor to initialize the token
    public JwtAuthProvider(String token) {
        this.token = token;
    }

    // Implement the abstract method Authenticate
    @Override
    public boolean Authenticate() {
        // Sample JWT validation logic, replace with real token validation
        return token != null && token.equals("valid-token");
    }

    // Getter (optional)
    public String getToken() { return token; }
}


