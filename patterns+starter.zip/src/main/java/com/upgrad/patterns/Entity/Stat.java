package com.upgrad.patterns.Entity;
public class Stat {
    private int confirmed;

    // Getter and setter
    public int getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(int confirmed) {
        this.confirmed = confirmed;
    }
}
