package com.upgrad.patterns.Entity;

public class DiseaseShResponse {
    private int active;
    private int cases;

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public int getCases() {
        return cases;
    }

    public void setCases(int cases) {
        this.cases = cases;
    }
}

