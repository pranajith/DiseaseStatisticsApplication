package com.upgrad.patterns.Entity;

public class JohnHopkinResponse {

    private String country;
    private Stat stats;

    // Constructor (optional)
    public JohnHopkinResponse() {}

    // Getter and Setter for country
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    // Getter and Setter for stats
    public Stat getStats() {
        return stats;
    }

    public void setStats(Stat stats) {
        this.stats = stats;
    }

    // Inner static class Stat
    public static class Stat {
        private int confirmed;
        private int deaths;
        private int recovered;

        // Constructor (optional)
        public Stat() {}

        // Getters and setters for each field
        public int getConfirmed() {
            return confirmed;
        }

        public void setConfirmed(int confirmed) {
            this.confirmed = confirmed;
        }

        public int getDeaths() {
            return deaths;
        }

        public void setDeaths(int deaths) {
            this.deaths = deaths;
        }

        public int getRecovered() {
            return recovered;
        }

        public void setRecovered(int recovered) {
            this.recovered = recovered;
        }
    }
}


