package com.upgrad.patterns.config;

import org.springframework.web.client.RestTemplate;

public class RestServiceGenerator {
    private static final RestTemplate restTemplate = new RestTemplate();

    public static RestTemplate getClient() {
        return restTemplate;
    }
}
