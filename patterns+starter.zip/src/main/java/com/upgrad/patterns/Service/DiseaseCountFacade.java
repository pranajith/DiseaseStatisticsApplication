package com.upgrad.patterns.service;

import org.springframework.stereotype.Service;

@Service
public class DiseaseCountFacade {

    // Mock data for demonstration
    private int indiaDiseaseStat = 1000;  // some dummy count
    private int diseaseShCount = 200;     // dummy count
    private int johnHopkinCount = 500;    // dummy count

    // Return disease count for India
    public int getIndiaDiseaseStat() {
        return indiaDiseaseStat;
    }

    // Return disease count from some other source
    public int getDiseaseShCount() {
        return diseaseShCount;
    }

    // Return count from Johns Hopkins data
    public int getJohnHopkinCount() {
        return johnHopkinCount;
    }

    // Calculate and return infected ratio (example calculation)
    public double getInfectedRatio() {
        int totalCases = indiaDiseaseStat + diseaseShCount + johnHopkinCount;
        if (totalCases == 0) {
            return 0.0;  // avoid division by zero
        }
        return (double) johnHopkinCount / totalCases;
    }
}
